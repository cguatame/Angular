import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ejemplo01',
  templateUrl: './ejemplo01.component.html',
  styleUrls: ['./ejemplo01.component.scss']
})
export class Ejemplo01Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
