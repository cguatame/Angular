export class Empleado {
  nombre: string = '';
  puesto: string = '';
  sueldo: number = 0;
}